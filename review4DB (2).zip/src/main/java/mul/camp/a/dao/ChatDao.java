package mul.camp.a.dao;

public interface ChatDao {

}
