package mul.camp.a.service;

public interface ChatService {

}
